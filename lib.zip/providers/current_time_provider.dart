import 'package:flutter/material.dart';

class CurrentTimeProvider with ChangeNotifier {}
